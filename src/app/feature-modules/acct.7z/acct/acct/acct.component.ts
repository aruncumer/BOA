import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-acct',
	template: `
	<app-acct-ui></app-acct-ui>
	`,
})

export class AcctComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}

}
